import { Injectable } from '@angular/core';
import { LocalStorageStoreService } from './local-storage-store.service';

@Injectable()
export class StoreService {

  constructor(private localStorageStore: LocalStorageStoreService) { }

  

}
