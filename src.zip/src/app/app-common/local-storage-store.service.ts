import { Injectable } from '@angular/core';
import { Ad } from '../ads/models/Ad';

@Injectable()

export class LocalStorageStoreService {

  constructor() { }

  setCollection(collectionName: string) {
    localStorage.setItem('ads', JSON.stringify(collectionName))
  }

}
