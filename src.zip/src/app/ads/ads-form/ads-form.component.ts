import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ads-form',
  templateUrl: './ads-form.component.html',
  styleUrls: ['./ads-form.component.css']
})
export class AdsFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
