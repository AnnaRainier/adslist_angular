import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdsFormComponent } from './ads-form/ads-form.component';
import { AdsEditComponent } from './ads-edit/ads-edit.component';
import { AdsContainerComponent } from './ads-container/ads-container.component';
import { AdsListComponent } from './ads-list/ads-list.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [AdsFormComponent, AdsEditComponent, AdsContainerComponent, AdsListComponent]
})
export class AdsModule { }
