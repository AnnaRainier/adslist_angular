export class Ad {
    id: number
    title: string
    descriprion: string
    autorName: string
    createdAt: string
}