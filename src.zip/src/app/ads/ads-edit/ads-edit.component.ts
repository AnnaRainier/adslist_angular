import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ads-edit',
  templateUrl: './ads-edit.component.html',
  styleUrls: ['./ads-edit.component.css']
})
export class AdsEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
