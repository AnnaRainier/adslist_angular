import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ads-container',
  templateUrl: './ads-container.component.html',
  styleUrls: ['./ads-container.component.css']
})
export class AdsContainerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
