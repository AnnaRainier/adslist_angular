import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing/app-routing.module';
import { AdsFormComponent } from './ads/ads-form/ads-form.component';
import { AdsListComponent } from './ads/ads-list/ads-list.component';
import { AdsModule } from './ads/ads.module';


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AdsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
