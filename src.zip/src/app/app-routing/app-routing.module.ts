import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AdsListComponent } from '../ads/ads-list/ads-list.component';
import { AdsEditComponent } from '../ads/ads-edit/ads-edit.component';

const routes: Routes = [
  {path: '', component: AdsListComponent, pathMatch: 'full'},
  {path: 'edit', component: AdsEditComponent},
  {path: 'delete/:id', redirectTo: ''}
]

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule { }
